<div class="form">
    <h2>Напишите нам!</h2>
    <form action="#">
        <table>
            <tr>
                <td>
                    <label>Имя:</label>
                </td>
                <td>
                    <input type="text" name="name" placeholder="Введите имя" size="30"> </td>
            </tr>
            <tr>
                <td>
                    <label>Email:</label>
                </td>
                <td>
                    <input type="email" name="email" placeholder="Введите e-mail" size="30"> </td>
            </tr>
            <tr>
                <td>Пол:</td>
                <td>
                    <label>
                        <input type="radio" name="sex">Мужской</label>
                    <label>
                        <input type="radio" name="sex">Женский</label>
                </td>
            </tr>
            <tr>
                <td>Инструменты:</td>
                <td class="instr">
                    <label>
                        <input type="checkbox" name="instrument">Гитара</label>
                    <label>
                        <input type="checkbox" name="instrument">Скрипка</label>
                    <label>
                        <input type="checkbox" name="instrument">Клавиши</label>
                </td>
            </tr>
            <tr>
                <td></td>
                <td class="instr">
                    <label>
                        <input type="checkbox" name="instrument">Ударные</label>
                    <label>
                        <input type="checkbox" name="instrument">Другое</label>
                </td>
            </tr>
            <tr>
                <td>
                    <label>Тема:</label>
                </td>
                <td>
                    <input type="text" name="theme" placeholder="Введите тему сообщения" size="30"> </td>
            </tr>
            <tr>
                <td>
                    <label>Сообщение:</label>
                </td>
                <td>
                    <textarea name="message" type="text" placeholder="Введите текст сообщения"></textarea>
                </td>
            </tr>
            <tr>
                <td></td>
                <td class="action_form">
                    <input type="reset" value="Очистить" class="button">
                    <input type="submit" value="Отправить" class="button"> </td>
            </tr>
        </table>
    </form>
</div>
<div class="address">
    <h2>Наш адрес</h2>
    <div class="map">
        <iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3Af1ee48f526c937a08a9f4716c0d01103b6a37a027f1f39c5f92f73c0b9a84252&amp;source=constructor" width="100%" height="374px" frameborder="0"></iframe>
    </div>
    <div class="address-table">
        <table>
            <tr>
                <td>Почтовый адрес:</td>
                <td>100500, 3-я улица Строителей, дом 25</td>
            </tr>
            <tr>
                <td>Телефон для связи:</td>
                <td> <a href="tel: +7100500100500">+7(4958)32-22-07</a> </td>
            </tr>
            <tr>
                <td>Наш e-mail:</td>
                <td> <a href="mailto: randommail@rm.org">randommail@rm.org</a> </td>
            </tr>
        </table>
    </div>
</div>