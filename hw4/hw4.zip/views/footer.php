</div>
<div class="footer">
  <p class="copy"><a href="http://geekbrains.ru" target="_blank">&copy; 2019 Все права защищены</a></p>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="js/main.js"></script>

</body>

</html>