<div class="welcome">
  Добро пожаловать!
</div>
<style>
  .welcome {
    width: 200px;
    height: 200px;
    margin: 200px auto;
  }
  </style>