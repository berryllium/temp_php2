<?php
class BaseModel {

}