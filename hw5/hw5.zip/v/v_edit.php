<?php
/**
 * Шаблон редактора
 * ================
 * $text - текст статьи
 */
?>

<form method="post">
	<textarea name="text"><?=$text?></textarea>
	<br/>
	<input type="submit" value="Сохранить" />
</form>
